library(testthat)
test_check("gmailr")
