# gmailr 0.7.1

* Bundle a application token and secret in gmailr so the average user won't need to create an application.
* Great number of bug fixes
* Reworking the print functions to provide more useful and easy to read output

# gmailr 0.5.0

### Major Changes

* Added ability to create and send drafts and messages. (#5, #6)
* Added a number of tests for mime message creation derived from the [Email::Stuffer](http://search.cpan.org/~rjbs/Email-Stuffer-0.009/lib/Email/Stuffer.pm) perl module.

### Minor Fixes

* Namespace was not properly updated (#2)
* added extraction functions for gmail_messages (#3)

# gmailr 0.0.1

* Initial release
