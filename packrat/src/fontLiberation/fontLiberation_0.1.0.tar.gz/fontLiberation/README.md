
# fontLiberation

This package is a placeholder for the Liberation fontset. It is
intended for the `fontquiver` package.

This fontset covers the 12 combinations of families (sans, serif,
mono) and faces (plain, bold, italic, bold italic) supported in R
graphics devices.
