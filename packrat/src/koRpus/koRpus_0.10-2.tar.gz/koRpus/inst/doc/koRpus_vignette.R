### R code from vignette source 'koRpus_vignette.Rnw'
### Encoding: UTF-8

