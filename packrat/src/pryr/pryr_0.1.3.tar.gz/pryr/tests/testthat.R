library("testthat")
library("pryr")

test_check("pryr")
