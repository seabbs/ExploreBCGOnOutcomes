#define USE_RINTERNALS
#include <Rinternals.h>

const int sexprec_size = sizeof(SEXPREC);
const int vector_sexprec_aligned_size = sizeof(SEXPREC_ALIGN);
