#ifndef RLANG_SYM_H
#define RLANG_SYM_H


SEXP r_sym(const char* c_string);


#endif
