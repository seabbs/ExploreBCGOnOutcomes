#ifndef RLANG_VECTOR_LIST_H
#define RLANG_VECTOR_LIST_H


void mut_list_at(SEXP list, R_len_t i, SEXP elt);


#endif
