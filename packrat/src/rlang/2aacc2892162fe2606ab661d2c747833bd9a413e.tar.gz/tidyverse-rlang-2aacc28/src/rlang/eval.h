#ifndef RLANG_EVAL_H
#define RLANG_EVAL_H


SEXP r_eval(SEXP expr, SEXP env);


#endif
